from django.test import SimpleTestCase, TestCase
from datetime import datetime

from ..models import Category
from ..forms import PostForm


class TestPostFrom(TestCase):

    def test_post_from_with_valid_data(self):
        cat_obj = Category.objects.create(name= 'test')
        form = PostForm(data={
            'title': 'test',
            'content':'description',
            'status': True,
            'category':cat_obj,
            'published_date': datetime.now()
        })
        self.assertTrue(form.is_valid())


    def test_post_from_with_no_data(self):
        form = PostForm(data={})
        self.assertFalse(form.is_valid())